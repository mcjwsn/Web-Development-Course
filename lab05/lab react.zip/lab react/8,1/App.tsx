import React from 'react'
import { useState } from 'react'
import Licznik from './Licznik'

function App() {
  

  return (
      <div>
        <Licznik></Licznik>
      </div>
  )
}

export default App

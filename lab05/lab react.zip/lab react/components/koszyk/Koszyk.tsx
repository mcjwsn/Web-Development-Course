import React from 'react';
import Produkt from './Produkt';

function Koszyk() {
    return (
      <div>
      <Produkt nazwa = 'melko'/>
      <Produkt nazwa = 'jajka'/>
      <Produkt nazwa = 'woda'/>
      <Produkt nazwa = 'chleb'/>
      <Produkt nazwa = 'maslo'/>
      <Produkt nazwa = 'test'/>
      </div>
    );}

export default Koszyk;